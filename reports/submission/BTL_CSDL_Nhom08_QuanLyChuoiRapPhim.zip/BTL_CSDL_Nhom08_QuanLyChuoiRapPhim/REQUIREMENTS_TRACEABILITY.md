# Ma trận đối chiếu bản nộp BTL Cơ sở dữ liệu

## Bản nộp hiện hành ngày 15/11/2026

Nhóm 8, INT1313-20261-01, giảng viên Nguyễn Quỳnh Chi. Các trọng số dưới đây lấy từ đề bài, không phải điểm tự chấm.

| Tiêu chí | Điểm | Sản phẩm và chương báo cáo | Bằng chứng hiện hành |
|---|---:|---|---|
| R1 Yêu cầu dữ liệu | 1,0 | Chương 1; docs/requirements/ | 14 nhóm quan hệ và BR-01..16 |
| R2 ERD | 2,5 | Chương 2; Chen/Crow's Foot puml/drawio/svg và PDF khổ lớn | tools/verify_erd.py; kiểm tra trực quan sơ đồ |
| R3 Quan hệ | 2,0 | Chương 3; schema-design.md và database/schema/ | MySQL8.4:14 bảng,17 FK,16 UNIQUE,19 CHECK,44 index |
| R4 3NF | 1,0 | Chương 4; normalization.md | FD/khóa; phép tách ticket lossless và bảo toàn FD đã phát biểu |
| R5 Hai form | 1,0 | Chương 5; quản lý suất chiếu, đặt vé | GUI đúng/sai; concurrency,2-JVM,UiTask và validation tests |
| R6 Tìm kiếm | 0,5 | Chương 6; tra cứu suất chiếu | GUI,ScreeningSearchIT; tổng kết quả và50 dòng/trang |
| R7 Hai báo cáo | 1,0 | Chương 7; doanh thu và bán vé | Preview/PDF tiếng Việt; SQL độc lập,RR snapshot,layout/failure tests |
| R8 Báo cáo và SQL | 1,0 | DOCX/PDF đủ7 chương; phụ lục SQL chức năng và DDL/FK/trigger/view | README_NOP_BAI.md; manifest/log/ảnh của bản nộp |

Bằng chứng thực thi mới: `verification/last-run.json`, `verification/test-results/summary.json`, `verification/submission-2026-11-15/verify-all.log`. Kết quả Java **104/104**, **15 suites**, Failures=0,Errors=0,Skipped=0. Công cụ Python 9 tests riêng. Khởi chạy thật Main trên demo: `main-demo-startup.log/.png` cùng thư mục bằng chứng.

Nâng cấp demo đã được người vận hành xác nhận: `verification/submission-2026-11-15/demo-trigger-upgrade/`. Chỉ12trigger đổi;14bảng/data/view giữ nguyên; hash mới `e827a6a114e7bf08c130792b34f8209398e09289131f14496d196d4c5568e5d1`. Bộ kiểm thử trước nâng cấp vẫn bảo toàn hash7af...; hai giai đoạn có bằng chứng riêng, không diễn giải hashDDL tổng là bất biến sau một migration đã được phép.

Phạm vi online: VNPay chỉ sandbox mô phỏng, chưa chứng nhận merchant/refund thật. Mốc40/53/95 tests phía dưới là lịch sử, không thay cho manifest104 hiện hành. Bản nộp Word/PDF dùng7 chương mới, các số chương trong lịch sử không còn là mục lục bản hiện hành.

## Lịch sử các mốc trước bản nộp hiện hành

# REQUIREMENTS_TRACEABILITY.md — Ma trận Truy vết Yêu cầu & Thang điểm (Rubric Traceability Matrix)

Tài liệu này ánh xạ trực tiếp 8 tiêu chí chấm điểm chính thức (**R1 – R8**, tổng cộng **10,0 điểm**, ưu tiên chất lượng học thuật **R1 – R4 = 6,5 điểm**) tới các sản phẩm thiết kế 14 bảng chuẩn 3NF, mã nguồn Java 21, kịch bản SQL trên **MySQL Community Server 8.4.0 LTS**, kết quả **diễn tập trực tiếp `com.cinema.app.Main` trên CSDL demo `cinema_chain`** (`2026-11-07 15:14`) và **40 bài kiểm thử tự động trên CSDL kiểm thử `cinema_chain_test` (`0 Skipped`, chạy lúc `2026-11-07 15:15:43`)**.

| Mã YC | Nội dung Yêu cầu Chính thức (Thang điểm) | Điểm | Tài liệu Thiết kế & Học thuật | Mã nguồn & Kịch bản SQL Thực thi | Bài Kiểm thử Tự động (`40/40 PASS, 0 Skipped`) | Bằng chứng Thực thi & Ảnh chụp | Chương trong Báo cáo Học thuật | Trạng thái |
|---|---|---:|---|---|---|---|---|---|
| **R1** | Mô tả yêu cầu nghiệp vụ và dữ liệu cần lưu | **1,0** | `docs/requirements/requirements.md`<br>`docs/requirements/business-rules.md` | `database/seed/10_seed.sql` | `DatabaseIntegrityIT.verifySeedDataScale` | `verification/logs/db_reset_test_verify.log` | Chương 1: Phân tích Yêu cầu Nghiệp vụ & Dữ liệu Cần Lưu trữ | **`ĐẠT` (`VERIFIED`)** |
| **R2** | Vẽ và mô tả mô hình thực thể – liên kết (ERD Chen & Crow's Foot) | **2,5** | `docs/erd/erd-chen.puml`<br>`docs/erd/erd-logical.puml`<br>`docs/erd/erd-explanation.md` | — | Đối chiếu đồng bộ 14 thực thể/quan hệ ↔ DDL (`Gate C.13`) | `docs/erd/erd-chen.png` / `.svg`<br>`docs/erd/erd-logical.png` / `.svg` | Chương 2: Thiết kế Sơ đồ Thực thể – Liên kết (ERD) | **`ĐẠT` (`VERIFIED`)** |
| **R3** | Mô hình quan hệ và mô tả bảng tương thích với ERD (14 bảng, 17 FK) | **2,0** | `docs/relational-model/schema-design.md` | `database/schema/01_schema.sql`<br>`database/schema/01b_foreign_keys.sql`<br>`database/schema/02_triggers.sql`<br>`database/schema/03_views.sql` | `DatabaseIntegrityIT` (**15/15** tests trên MySQL 8.4.0)<br>`TestSafetyGuardTest` (**6/6**) | `verification/logs/db_reset_test_verify.log`<br>`verification/logs/migration_clone_dryrun.log`<br>`verification/test-results/TEST-com.cinema.integration.DatabaseIntegrityIT.xml` | Chương 3: Lược đồ Cơ sở Dữ liệu Quan hệ & Từ điển Dữ liệu | **`ĐẠT` (`VERIFIED`)** |
| **R4** | Kiểm tra các bảng và đưa về 3NF thực sự (xử lý phụ thuộc bắc cầu trên `ticket`, chứng minh Lossless-Join & bảo toàn FD) | **1,0** | `docs/normalization/normalization.md` | `database/schema/01_schema.sql`<br>`database/migrations/V2_3nf_ticket_up.sql` | `DatabaseIntegrityIT.ticketTableMustSatisfyStrict3NfAndSeatLockTableMustRejectDirectTampering`<br>`historicalTicketPriceMustRemainUnchangedWhenCurrentPricingChanges` | `docs/normalization/normalization.md`<br>`verification/logs/migration_clone_dryrun.log` | Chương 4: Phụ thuộc Hàm, Phép Phân rã & Chứng minh Chuẩn hóa 3NF | **`ĐẠT` (`VERIFIED`)** |
| **R5** | Hai form nhập liệu, demo kiểm tra dữ liệu đúng/sai:<br>1. Quản lý Suất chiếu<br>2. Đặt vé & Chọn ghế | **1,0** | `ARCHITECTURE.md`<br>`docs/requirements/business-rules.md`<br>`docs/sql-features/functional-sql-mapping.md` | `com.cinema.feature.screening.*`<br>`com.cinema.feature.booking.*` | `ScreeningValidationTest` (**5/5**)<br>`ScreeningConcurrencyIT` (**2/2**)<br>`BookingConcurrencyIT` (**1/1**)<br>`ArchitectureComplianceTest` (**5/5**)<br>`GuiVerificationRunner` & `AppPersistenceVerificationRunner` | `verification/screenshots/01_screening_management_valid.png`<br>`02_screening_management_overlap_rejected.png`<br>`03_ticket_booking_seat_selection.png`<br>`04_ticket_booking_success.png`<br>`04b_ticket_booking_occupied_rejected.png`<br>`verification/logs/gui_verification_test_db.log`<br>`verification/logs/persistence_restart_verify.log` | Chương 5 (Mục 5.1, 5.2, 5.3 & Mục 5.7 SQL R5) | **`ĐẠT` (`VERIFIED`)** |
| **R6** | Một màn hình tìm kiếm và hiển thị kết quả (kèm phân trang 50 dòng/trang, không cắt ngầm) | **0,5** | `ARCHITECTURE.md`<br>`docs/sql-features/functional-sql-mapping.md` | `com.cinema.feature.search.*`<br>`database/queries/functional_sql_verification.sql` | `ScreeningSearchIT` (**3/3** — gồm kiểm chứng đủ dữ liệu qua các trang) | `verification/screenshots/05_screening_search.png`<br>`verification/test-results/TEST-com.cinema.integration.ScreeningSearchIT.xml` | Chương 5 (Mục 5.4 & Mục 5.7 SQL R6) | **`ĐẠT` (`VERIFIED`)** |
| **R7** | Hai báo cáo xem trên màn hình và xuất file giống thực tế; nêu rõ người lập & người nhận:<br>1. Báo cáo Doanh thu (*Kế toán → Giám đốc Kinh doanh*)<br>2. Báo cáo Bán vé (*Quản lý Chi nhánh → Ban Điều hành / QL Kinh doanh*) | **1,0** | `ARCHITECTURE.md`<br>`docs/sql-features/functional-sql-mapping.md` | `com.cinema.feature.report.revenue.*`<br>`com.cinema.feature.report.sales.*`<br>`com.cinema.reporting.PdfReportWriter` | `ReportAccuracyIT` (**3/3**: SQL độc lập + Known-Answer Fixture) | `verification/screenshots/06_revenue_report_preview.png`<br>`07_ticket_sales_report_preview.png`<br>`08_exported_revenue_pdf_page1.png`<br>`09_exported_sales_pdf_page1.png`<br>`reports/exports/BaoCaoDoanhThu_Mau.pdf`<br>`reports/exports/BaoCaoBanVe_Mau.pdf` | Chương 5 (Mục 5.5, 5.6 & Mục 5.7 SQL R7) | **`ĐẠT` (`VERIFIED`)** |
| **R8** | Báo cáo bao phủ đủ R1–R7, kèm SQL cài đặt và SQL tương ứng các chức năng R5–R7 | **1,0** | Toàn bộ `docs/` & `DEMO_GUIDE.md` | `database/schema/*.sql`<br>`database/queries/functional_sql_verification.sql`<br>`database/queries/business_queries.sql`<br>`tools/build_academic_report.py` | Toàn bộ 40 bài test (`.\mvnw.cmd clean verify -Pmysql-it`) + thực thi `functional_sql_verification.sql` | `docs/academic-report/BaoCao_QuanLyChuoiRap.docx`<br>`docs/academic-report/BaoCao_QuanLyChuoiRap.pdf`<br>`verification/logs/functional_sql_examples_test_db.log` | Chương 1 – Chương 6 & Phụ lục A1, A2, B, C, D1, D2 | **`ĐẠT` (`VERIFIED`)** |

---

### Phân biệt Minh bạch Kết quả trên CSDL Demo (`cinema_chain`) và CSDL Kiểm thử (`cinema_chain_test`)
- **Hệ quản trị chạy thực tế:** **MySQL Community Server 8.4.0 LTS** (`127.0.0.1:3306`, `datadir = C:/Users/LNB/.mysql/data-8.4`). Chỉ thao tác trên 2 CSDL của dự án (`cinema_chain` và `cinema_chain_test`), giữ nguyên tuyệt đối mọi CSDL khác trên máy chủ.
- **1. Kết quả Trình diễn Trực tiếp trên CSDL Demo `cinema_chain` (14 bảng chuẩn 3NF):**
  - Đã khởi tạo `cinema_chain` với đúng **14 bảng chuẩn 3NF, 17 khóa ngoại, 12 Trigger, 4 View** và dữ liệu mẫu hợp lệ (`35.165.000,00 VNĐ`, dấu vân tay seed gốc `fc060239eb1a...`, log: `verification/logs/cinema_chain_14table_provision.log`).
  - Đã khởi chạy `com.cinema.app.Main` bằng cấu hình mặc định `config/application.properties` (`DB=cinema_chain`, `User=cinema_app`, `Mode=NORMAL_READ_ONLY_INIT | DestructiveReset=DISABLED`).
  - Đã kiểm tra đầy đủ **cả dữ liệu hợp lệ và dữ liệu bị từ chối** trên cả 5 màn hình, tạo mới Suất chiếu `#161` (`2026-11-18`) + Đơn `#161` (`CONFIRMED`, ghế `A01 + E01 = 210.000 VNĐ`) + hủy hoàn tiền Đơn `#162` (`CANCELLED`/`REFUNDED`), xuất 2 báo cáo PDF (`reports/exports/BaoCaoDoanhThu_CinemaChain_Demo.pdf` và `reports/exports/BaoCaoBanVe_CinemaChain_Demo.pdf`) khớp tuyệt đối truy vấn SQL độc lập (`35.375.000,00 VNĐ`, sai lệch `0,00 VNĐ`), sau đó **đóng hoàn toàn ứng dụng và mở lại `Main` trong tiến trình JVM mới** xác nhận toàn bộ dữ liệu demo vừa nhập vẫn còn nguyên vẹn (`verification/logs/demo_cinema_chain_live_verify.log`, ảnh chụp `verification/screenshots/demo_cinema_chain_01_*.png` .. `10_*.png`).
- **2. Kết quả Kiểm thử Tự động Hồi quy trên CSDL Kiểm thử `cinema_chain_test`:**
  - Chạy tươi `database/verify_all.ps1` lúc `2026-11-07 15:15:43`: **`40/40 PASS, 0 Failures, 0 Errors, 0 Skipped`** trên `cinema_chain_test`; đồng thời dấu vân tay SHA-256 của `cinema_chain` (bao gồm cả dữ liệu demo vừa nhập) trước và sau khi chạy bộ test đều khớp tuyệt đối `7af5d0052ade56eedd37184d82ce7a00a178bbcaa7806f828e06ed23aaa66d37` (`verification/logs/cinema_chain_baseline_fingerprint.json`).
- **Minh bạch phạm vi kiểm thử GUI:** Giao diện Swing được kiểm chứng tự động thông qua điều khiển EDT (`DemoCinemaChainVerificationRunner`, `GuiVerificationRunner`, `AppPersistenceVerificationRunner`); thao tác bấm chuột/bàn phím vật lý của người trình bày được thực hiện theo checklist tại `DEMO_GUIDE.md`.


## Kiểm thử dataset bổ sung — 2026-11-13

Cinema Sample Database 1K: **3/3 PASS, Failures=0, Errors=0, Skipped=0**;
1.000 vé, 450 đơn, 15 suất. Bộ hồi quy gốc: **40/40 PASS**;
`verify_all.ps1` hoàn tất cả 6 bước trên MySQL 8.4/JDK 21.
SHA-256 `cinema_chain` trước/sau khớp
`7af5d0052ade56eedd37184d82ce7a00a178bbcaa7806f828e06ed23aaa66d37`.
Bằng chứng: `verification/dataset-sample/README.md`, `manifest.json`,
`result.json`, `TEST-CinemaDatasetCheck.xml`, `dataset-test.log` và `verify-all.log`.
R5: chặn ghế trùng qua service và SQL; R6: phân trang/số ghế;
R7: đối chiếu ledger CSV với báo cáo từng chi nhánh.
GUI/PDF chỉ chạy lại với fixture gốc; chưa kiểm thử GUI trên dataset,
chưa đo tải 100K/1M. Không đổi trạng thái VERIFIED của các mục hiện có.


## Kiểm thử mức 2 và 4 — 2026-11-13

Bổ sung `PaymentRecoveryIT`: **13/13 PASS** (8 test trạng thái thanh toán,
5 test sự cố/rollback), không lỗi và không bỏ qua. Đã tái hiện lỗi trước sửa
(`verification/payment-recovery/red.log`, `RED-PaymentRecoveryIT.xml`).
Sửa `TransactionTemplate` rollback cả Error; hai trigger payment chặn SUCCESS
sai số tiền hoặc đơn đã hủy. Không đổi cấu trúc bảng, kiểu cột hoặc tập trạng thái.
Toàn bộ bộ test mặc định: **53/53 PASS, Failures=0, Errors=0, Skipped=0**;
dataset 1K chạy riêng **3/3 PASS**. `verify_all.ps1` hoàn tất 6 bước,
bao gồm GUI/PDF, hai JVM và SQL chức năng. Đã xem ảnh PDF được kết xuất.
Dữ liệu kiểm thử đã dọn; SHA-256 `cinema_chain` trước/sau khớp
`7af5d0052ade56eedd37184d82ce7a00a178bbcaa7806f828e06ed23aaa66d37`.
Bằng chứng và giới hạn: `verification/payment-recovery/README.md`, `result.json`,
`GREEN-PaymentRecoveryIT.xml`, `verify-all.log`, `DATASET-CinemaDatasetCheck.xml`.
Liên hệ BR-13/R5: từ chối thanh toán sai và lặp; BR-10/R5: không để khóa ghế
mồ côi sau sự cố; BR-14/R7: giữ tính nhất quán tiền/vé khi chuyển trạng thái.
Trigger mới chỉ áp dụng trên `cinema_chain_test`; **DB demo chưa được migration**.
Chưa thử mất điện, crash MySQL hoặc mất phản hồi đúng lúc COMMIT.
Không thay đổi trạng thái VERIFIED của các mục hiện có.


## Kiểm thử nghiệp vụ chuyên sâu và VNPay Sandbox — 2026-11-13

Bộ mặc định **95/95 PASS, Failures=0, Errors=0, Skipped=0** (XML tươi, 12 suite);
dataset 1K chạy riêng **3/3 PASS**. Có 17 test BusinessRulesIT, 10 test giao thức
VnpayGatewayTest và 15 test SandboxPaymentIT (HTTP/JDBC thật, chữ ký provider giả lập).
Đã chạy lại verify_all.ps1 đủ 6 bước, kiểm tra giao diện sandbox thiếu merchant,
xem ảnh thực tế và SQL độc lập trên toàn DB test: 9 bộ đếm sai lệch/fixture đều 0.
Lỗi trước sửa và kết quả sau sửa: verification/business-audit/README.md, red.log,
state-red.log, scheduling-red.log, verify-all.log, result.json và sandbox-ui-unconfigured.png.
Sửa kiểm tra chi nhánh hoạt động, bảo toàn doanh thu lịch sử, validation ghế,
khóa lịch SQL đồng thời, bất biến giá vé, bảo vệ vé/đơn đã hủy, đồng bộ hủy và
điều kiện xác nhận thanh toán. Giữ 14 bảng, 12 trigger, tập trạng thái hiện có.
Đặc tả/giới hạn sandbox: docs/requirements/sandbox-payment.md.
SHA-256 cinema_chain trước/sau khớp
7af5d0052ade56eedd37184d82ce7a00a178bbcaa7806f828e06ed23aaa66d37.
Chưa có merchant: chưa kiểm chứng giao dịch VNPay thật, public IPN hoặc refund/query.
Trigger mới chỉ áp dụng DB test; DB demo chưa migration. Không đổi trạng thái
VERIFIED hiện có để suy diễn gateway đã VERIFIED.
